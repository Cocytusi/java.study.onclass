import java.util.Date;
import java.util.Locale;
public class DataFormat {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1
		Date today = new Date();
		String a1 = String.format("%tF", today);
		System.out.println(a1);
		String b1 = String.format("%tD", today);
		System.out.println(b1);
		String c1 = String.format("%tr", today);
		System.out.println(c1);
		String d1 = String.format("%tT", today);
		System.out.println(d1);
		String e1 = String.format("%tR", today);
		System.out.println(e1);
		System.out.println();
		//2
		String a2 = String.format(Locale.US,"%tb", today);
		String b2 = String.format(Locale.US,"%tB", today);
		String c2 = String.format("%ta", today);
		String d2 = String.format("%tA", today);
		String e2 = String.format("%tY", today);
		String f2 = String.format("%ty", today);
		String g2 = String.format("%tm", today);
		String h2 = String.format("%td", today);
		String i2 = String.format("%te", today);
		String j2 = String.format("%tj", today);
		System.out.println(a2);
		System.out.println(b2);
		System.out.println(c2);
		System.out.println(d2);
		System.out.println(e2);
		System.out.println(f2);
		System.out.println(g2);
		System.out.println(h2);
		System.out.println(i2);
		System.out.println(j2);
		System.out.println();
		//3
		String a3 = String.format("%tH", today);
		String b3 = String.format("%tk", today);
		String c3 = String.format("%tI", today);
		String d3 = String.format("%tl", today);
		String e3 = String.format("%tM", today);
		String f3 = String.format("%tS", today);
		String g3 = String.format("%tp", today);
		String h3 = String.format(Locale.US,"%tp", today);
		System.out.println(a3);
		System.out.println(b3);
		System.out.println(c3);
		System.out.println(d3);
		System.out.println(e3);
		System.out.println(f3);
		System.out.println(g3);
		System.out.println(h3);
	}

}
