import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file = new File("G:/","PhoneNumber.txt");
		try{
			file.createNewFile();
		}catch(IOException e){
			e.printStackTrace();
		}
		
		String s = "2015211854";
		byte b[]=new byte[512];
		b = s.getBytes();
		try{
			FileOutputStream in = new FileOutputStream(file);
			try{
				in.write(b, 0, b.length);
				in.close();
			}catch(IOException e){
				e.printStackTrace();
			}
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}
	}

}
