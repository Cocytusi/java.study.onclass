import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Copy {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File sfile = new File("G:/", "PhoneNumber.txt");
		try {
			sfile.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}

		File tofile = new File("G:/", "PhoneNumber(0).txt");
		try {
			tofile.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			FileInputStream ins = new FileInputStream(sfile);
			FileOutputStream out = new FileOutputStream(tofile);
			byte[] b = new byte[512];
			int n = 0;
			while ((n = ins.read(b)) != -1) {
				out.write(b, 0, b.length);
			}
			ins.close();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
