package work2;
import work2.Student;
public class scoreSort{
	@SuppressWarnings("null")
	public static void main( String args[] ){
		Student a = new Student("2017329231","Steve",87,93,97,100);
		Student b = new Student("2017329232","Ais",59,77,99,88);
		Student c = new Student("2017329233","Cytus",67,86,97,96);
		
		Student stu[] = new Student[4];
		for(int i=0;i<3;i++){
			stu[i] = new Student();
		}
		
		stu[0] = a;
		stu[1] = b;
		stu[2] = c;
		stu[3] = new Student();
		
		for(int i=0;i<3;i++){
			if(stu[i].totalScore<stu[i+1].totalScore){
				stu[3] = stu[i];
				stu[i] = stu[i+1];
				stu[i+1] = stu[3];
			}
		}
		
		for(int i=0;i<3;i++){
			System.out.println("NO."+(i+1));
			stu[i].show();
			System.out.println();
		}
		
	}
}
