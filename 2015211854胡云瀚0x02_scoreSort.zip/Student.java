package work2;
public class Student {
	String stu_number = new String();	//ѧ��
	String stu_name = new String();		//����
	int math_score;						//��ѧ�ɼ�
	int java_score;						//java�ɼ�
	int assembly_score;					//���ɼ�
	int database_score;					//���ݿ�ɼ�
	int totalScore;						//�ܳɼ�
	
	public Student(){
		stu_number = "0000000000";
		stu_name = "XXX";
		math_score = 0;
		java_score = 0;
		assembly_score = 0;	
		database_score = 0;
		totalScore = totalScore();
	}
	
	public Student(String number,String name){
		this();
		this.stu_number = number;
		this.stu_name = name;
		totalScore = totalScore();
	}
	
	public Student(String number,String name,int math,int java,int assembly,int database){
		this(number,name);
		this.math_score = math;
		this.java_score = java;
		this.assembly_score = assembly;	
		this.database_score = database;
		totalScore = totalScore();
	}
	
	public int totalScore(){
		return math_score+java_score+assembly_score+database_score;
	}
	
	public void show(){
		System.out.println("Student Number:" + stu_number );
		System.out.println("Student Name:" + stu_name );
		System.out.println("Math Score:" + math_score );
		System.out.println("Java Score:" + java_score );
		System.out.println("Assembly Score:" + assembly_score );
		System.out.println("Database Score:" + database_score );
		System.out.println("Total Score:" + totalScore );
	}
	
}
