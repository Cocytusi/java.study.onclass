import java.util.Iterator;
import java.util.TreeSet;

public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person person1 = new Person("������",220181);
		Person person2 = new Person("������",220186);
		Person person3 = new Person("��С��",220193);
		Person person4 = new Person("������",220196);
		Person person5 = new Person("������",220175);
		TreeSet<Person> treeSet = new TreeSet<Person>();
		treeSet.add(person1);
		treeSet.add(person2);
		treeSet.add(person3);
		treeSet.add(person4);
		treeSet.add(person5);
		System.out.println("��ʼ���ļ���");
		Iterator<Person> it = treeSet.iterator();
		while(it.hasNext()){
			Person person = it.next();
			System.out.println("------"+person.getId_card()+" "+person.getName());
		}
		System.out.println("��ȡǰ�沿�ֵõ��ļ��ϣ�");
		it = treeSet.headSet(person1).iterator();
		while(it.hasNext()){
			Person person = it.next();
			System.out.println("------"+person.getId_card()+" "+person.getName());
		}
		System.out.println("��ȡ�м䲿�ֵõ��ļ��ϣ�");
		it = treeSet.subSet(person1,person3).iterator();
		while(it.hasNext()){
			Person person = it.next();
			System.out.println("------"+person.getId_card()+" "+person.getName());
		}
		System.out.println("��ȡ���沿�ֵõ��ļ��ϣ�");
		it = treeSet.tailSet(person3).iterator();
		while(it.hasNext()){
			Person person = it.next();
			System.out.println("------"+person.getId_card()+" "+person.getName());
		}
	}

}
