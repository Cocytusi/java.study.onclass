public class Point {
	int x;
	int y;
	
	Point(){
		x = 0;
		y = 0;
	}
	
	Point(int X){
		x = X;
		y = 0;
	}
	
	Point(int X,int Y){
		x = X;
		y = Y;
	}
}
