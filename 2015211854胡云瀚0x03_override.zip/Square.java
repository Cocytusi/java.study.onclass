public class Square extends Point {
	int l;
	
	Square(){
		super();
		l = 1;
	}
	
	Square(Point p){
		super(p.x,p.y);
		l = 1;
	}
	
	Square(Point p,int L){
		super(p.x,p.y);
		l = L;
	}
}
