public class Circle extends Point {
	int r;
	
	Circle(){
		super();
		r = 1;
	}
	
	Circle(Point p){
		super(p.x,p.y);
		r = 1;
	}
	
	Circle(Point p,int R){
		super(p.x,p.y);
		r = R;
	}
}
